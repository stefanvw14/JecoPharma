﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPL3._0.Model
{
    class Persoon : Model
    {
        private string naam;
        private string adres;
        private string woonplaats;

        public string Naam
        {
            get { return this.naam; }
            set
            {
                if(this.naam != value)
                {
                    this.naam = value;
                    this.changed();
                }
            }
        }

        public string Adres
        {
            get { return this.adres; }
            set
            {
                if (this.adres != value)
                {
                    this.adres = value;
                    this.changed();
                }
            }
        }

        public string Woonplaats
        {
            get { return this.woonplaats; }
            set
            {
                if (this.woonplaats != value)
                {
                    this.woonplaats = value;
                    this.changed();
                }
            }
        }

        public Persoon() : this("", "", "")
        { }
        
        public Persoon(string naam, string adres, string woonplaats)
        {
            this.naam = naam;
            this.adres = adres;
            this.woonplaats = woonplaats;
        }

        public override string ToString()
        {
            return this.naam;
        }
    }
}
