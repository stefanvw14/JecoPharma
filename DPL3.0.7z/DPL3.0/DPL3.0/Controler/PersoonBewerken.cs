﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DPL3._0.Model;

namespace DPL3._0.Controler
{
    class PersoonBewerken
    {
        private Model.Adresboek adresboek;
        private Model.Persoon p;
        private bool nieuwPersoon;
        private Persoon view;

        public PersoonBewerken(Model.Adresboek adresboek)
        {
            this.adresboek = adresboek;
            this.p = new _0.Model.Persoon();
            //this.nieuwPersoon = true;
            this.view = new Persoon();
            this.p.addView(this.view);

            // koppel ok 
            this.view.btnOk.Click += new EventHandler(btnOk_Click);
            //koppel annuleren
            this.view.btnAnnuleren.Click += new EventHandler(btnAnnuleren_Click);
            this.view.Show();
        }
        public PersoonBewerken(Model.Adresboek adresboek, Model.Persoon p)
        {
            this.adresboek = adresboek;
            this.p = p;
            //this.nieuwPersoon = false;
            this.view = new Persoon();
            this.p.addView(this.view);
            this.view.update(this.p);

            // koppel ok 
            this.view.btnOk.Click += new EventHandler(btnNieuw_Click);
            //koppel annuleren
            this.view.btnAnnuleren.Click += new EventHandler(btnAnnuleren_Click);
            this.view.Show();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string naam, adres, woonplaats;
            naam = this.view.txtNaam.Text;
            adres = this.view.txtAdres.Text;
            woonplaats = this.view.txtWpl.Text;
            p.Naam = naam;
            p.Adres = adres;
            p.Woonplaats = woonplaats;

            this.adresboek.aanmaken(p);

            if(this.nieuwPersoon)
            {
                this.adresboek.aanmaken(this.p);
            }

            this.view.Close();
            this.p.removeView(this.view);
        }

        private void btnAnnuleren_Click(object sener, EventArgs e)
        {
            this.view.Close();
            this.p.removeView(this.view);
        }

        private void btnNieuw_Click(object sender, EventArgs e)
        {
            string naam, adres, woonplaats;
            naam = this.view.txtNaam.Text;
            adres = this.view.txtAdres.Text;
            woonplaats = this.view.txtWpl.Text;
            p.Naam = naam;
            p.Adres = adres;
            p.Woonplaats = woonplaats;

            this.view.Close();
            this.p.removeView(this.view);
        }

        public Model.Persoon Model { get; internal set; }
        public Persoon View { get; internal set; }
    }
}
