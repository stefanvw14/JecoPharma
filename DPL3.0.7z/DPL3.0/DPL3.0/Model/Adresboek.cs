﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPL3._0.Model
{
    class Adresboek : Model, IView
    {
        private List<Persoon> personen;

        public List<Persoon> Personen
        {
            get { return this.personen; }
        }
        public Adresboek()
        {
            this.personen = new List<Persoon>();
        }

        public List<Persoon> geeflijst()
        {
            return this.personen;
        }

        public List<Persoon> zoeken(string tekst)
        {
            List<Persoon> resultaten = new List<Persoon>();

            foreach(Persoon persoon in this.personen)
            {
                if(persoon.Naam.Contains(tekst) || persoon.Adres.Contains(tekst) || persoon.Woonplaats.Contains(tekst))
                {
                    resultaten.Add(persoon);
                }
            }
            return personen;

        }

        public void aanmaken(Persoon p)
        {
            this.personen.Add(p);
            p.addView(this);
            this.changed();
        }

        public void verwijderen(Persoon p)
        {
            this.personen.Remove(p);
            p.removeView(this);
            this.changed();
        }

        public void update(Model m)
        {
            this.changed();
        }
    }
}
