﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPL3._0.Model
{
    public interface IView
    {
        void update(Model m);
    }
}
