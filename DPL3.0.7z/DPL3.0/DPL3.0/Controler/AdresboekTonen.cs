﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DPL3._0.Controler
{
    class AdresboekTonen
    {
        private Model.Adresboek adresboek;
        private Adresboek view;

        private PersoonBewerken pb;

        public AdresboekTonen()
        {
            this.adresboek = new Model.Adresboek();
            this.view = new Adresboek();
            this.adresboek.addView(view);
            this.view.update(this.adresboek);

            this.adresboek.aanmaken(new Model.Persoon("Jeroen", "Bergerweg 200", "Alkmaar"));
            this.adresboek.aanmaken(new Model.Persoon("Cora", "Bergerweg 200", "Alkmaar"));

            this.view.btnNieuw.Click += new EventHandler(btnNieuw_Click);
            this.view.btnWijzig.Click += new EventHandler(btnWijzig_Click);

            Application.Run(this.view);
        }

        private void btnNieuw_Click(object sender, EventArgs e)
        {
            pb = new PersoonBewerken(this.adresboek);
        }

        private void btnWijzig_Click(object sender, EventArgs e)
        {
            if(this.view.lbPersonen.SelectedIndex != -1)
            {
                Model.Persoon p = (Model.Persoon)this.view.lbPersonen.Items[this.view.lbPersonen.SelectedIndex];
                this. pb = new PersoonBewerken(this.adresboek, p);
            }
        }


    }
}
