﻿namespace DPL3._0
{
    partial class Adresboek
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnZoek = new System.Windows.Forms.Button();
            this.btnNieuw = new System.Windows.Forms.Button();
            this.btnWijzig = new System.Windows.Forms.Button();
            this.btnVerwijder = new System.Windows.Forms.Button();
            this.lbPersonen = new System.Windows.Forms.ListBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnZoek
            // 
            this.btnZoek.Location = new System.Drawing.Point(200, 12);
            this.btnZoek.Name = "btnZoek";
            this.btnZoek.Size = new System.Drawing.Size(151, 34);
            this.btnZoek.TabIndex = 1;
            this.btnZoek.Text = "Zoeken";
            this.btnZoek.UseVisualStyleBackColor = true;
            // 
            // btnNieuw
            // 
            this.btnNieuw.Location = new System.Drawing.Point(200, 52);
            this.btnNieuw.Name = "btnNieuw";
            this.btnNieuw.Size = new System.Drawing.Size(151, 34);
            this.btnNieuw.TabIndex = 2;
            this.btnNieuw.Text = "Nieuw";
            this.btnNieuw.UseVisualStyleBackColor = true;
            // 
            // btnWijzig
            // 
            this.btnWijzig.Location = new System.Drawing.Point(200, 92);
            this.btnWijzig.Name = "btnWijzig";
            this.btnWijzig.Size = new System.Drawing.Size(151, 40);
            this.btnWijzig.TabIndex = 3;
            this.btnWijzig.Text = "Wijzig";
            this.btnWijzig.UseVisualStyleBackColor = true;
            // 
            // btnVerwijder
            // 
            this.btnVerwijder.Location = new System.Drawing.Point(200, 138);
            this.btnVerwijder.Name = "btnVerwijder";
            this.btnVerwijder.Size = new System.Drawing.Size(151, 35);
            this.btnVerwijder.TabIndex = 4;
            this.btnVerwijder.Text = "Verwijder";
            this.btnVerwijder.UseVisualStyleBackColor = true;
            // 
            // lbPersonen
            // 
            this.lbPersonen.FormattingEnabled = true;
            this.lbPersonen.Location = new System.Drawing.Point(13, 31);
            this.lbPersonen.Name = "lbPersonen";
            this.lbPersonen.Size = new System.Drawing.Size(120, 95);
            this.lbPersonen.TabIndex = 5;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(200, 192);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 6;
            this.btnOk.Text = "OKÉ";
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // Adresboek
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 261);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.lbPersonen);
            this.Controls.Add(this.btnVerwijder);
            this.Controls.Add(this.btnWijzig);
            this.Controls.Add(this.btnNieuw);
            this.Controls.Add(this.btnZoek);
            this.Name = "Adresboek";
            this.Text = "Adresboek";
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.Button btnZoek;
        public System.Windows.Forms.Button btnNieuw;
        public System.Windows.Forms.Button btnWijzig;
        public System.Windows.Forms.Button btnVerwijder;
        private System.Windows.Forms.Button btnOk;
        public System.Windows.Forms.ListBox lbPersonen;
    }
}