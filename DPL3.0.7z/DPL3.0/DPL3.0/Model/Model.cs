﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPL3._0.Model
{
    public class Model
    {
        private List<IView> views;

        public Model()
        {
            this.views = new List<IView>();
        }
        public void addView(IView view)
        {
                this.views.Add(view);
        }

        public void removeView(IView view)
        {
                this.views.Remove(view);
        }
        protected void changed()
        {
            //volgens jeroen
            foreach(IView view in this.views)
            {
                view.update(this); //geef het huidige model mee aan de view
            }
        }

    }
}
