﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DPL3._0.Model;

namespace DPL3._0
{
    public partial class Persoon : Form, Model.IView
    {
        public Persoon()
        {
            InitializeComponent();
        }

        public void update(Model.Model m)
        {
            if (m is Model.Persoon)
            {
                Model.Persoon persoon = (Model.Persoon)m;
                this.txtNaam.Text = persoon.Naam;
                this.txtAdres.Text = persoon.Adres;
                this.txtWpl.Text = persoon.Woonplaats;
                //this.lbPersonen.Items.Clear();
                /*foreach (Model.Persoon p in persoon.geeflijst())
                {
                //    this.lbPersonen.Items.Add(p);
                }*/
            }
        }
    }
}
