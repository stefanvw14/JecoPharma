﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DPL3._0
{
    public partial class Adresboek : Form, Model.IView
    {
        public Adresboek()
        {
            InitializeComponent();
        }

        public void update(Model.Model m)
        {
            if(m is Model.Adresboek)
            {
                Model.Adresboek adresboek = (Model.Adresboek)m;
                this.lbPersonen.Items.Clear();
                foreach (Model.Persoon p in adresboek.geeflijst())
                {
                    this.lbPersonen.Items.Add(p);
                }
            }
        }
    }
}
